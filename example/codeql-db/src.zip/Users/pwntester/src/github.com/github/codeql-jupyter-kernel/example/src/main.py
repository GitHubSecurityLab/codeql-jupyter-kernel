import subprocess

subprocess.call(["python", "main.py"])
